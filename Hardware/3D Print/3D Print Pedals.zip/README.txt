Pedal with potentiometer by Fergobirck on Thingiverse: https://www.thingiverse.com/thing:4798296

Summary:
This is a remake of the great design by stephanemermet. Here's the original:https://www.thingiverse.com/thing:4300675The aim for this remake is to invert the rack and pinion mechanism so it goes to the front of the pedal instead of below, allowing you to mount it directly on a surface.